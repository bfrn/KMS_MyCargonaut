var User = /** @class */ (function () {
    function User(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    return User;
}());
export { User };
//# sourceMappingURL=User.js.map